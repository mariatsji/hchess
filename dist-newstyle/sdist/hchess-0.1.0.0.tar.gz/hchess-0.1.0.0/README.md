# hchess

# run tests

    nix-shell
    cabal test

# start app

    nix-shell
    cabal run hchess
    
    
